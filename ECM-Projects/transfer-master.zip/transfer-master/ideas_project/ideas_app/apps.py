from django.apps import AppConfig


class IdeasAppConfig(AppConfig):
    name = 'ideas_app'
