from django.contrib import admin
from .models import Idea

# Register your models here.

admin.site.register(Idea)