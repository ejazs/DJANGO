from django.shortcuts import render
from .models import Comment
# Create your views here.

# def update_comment()