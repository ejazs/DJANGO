from django.apps import AppConfig


class TrackingAppConfig(AppConfig):
    name = 'tracking_app'
